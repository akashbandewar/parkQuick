package com.ParkQuickBackend.entity;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



public class BookingInfo {

	/*	
	private int bookingId;
	
	private int ownerId;
	
	private int customerId;
	
	private String vehicleType;
	
	private String vehicleNo;
	
	private String checkIn;
	
	private String checkOut;
	
	private String bookingStatus;
	
	private int totalCost;
	
	@ManyToOne
	@JoinColumn(name="parkingId")
	private ParkingInfo parkingId;
	
	

	*/
}
